#Fargateデプロイまでの手順

1.ECSタスク定義のchobiitInvalidating-taskを押す  
2.タスク定義のchobiitInvalidating-task:8を選択肢、アクションのセレクトからタスク実行を押す  
3.タスク実行の選択項目は以下のように選択し、アスクの実行を押す。  

・起動タイプ > FARGATE  
・クラスター > chobiitInvalidating-cluster  
・クラスターVPC > vpc5a42893f  
・サブネット > subnet-baec5adf  

4.ログを確認の際はECSのサイドバーのクラスターを選択し、chobiitInvalidating-clusterを選択。ページ下部のタスクを選び、実行したタスクを押す。タスクページの下にある「コンテナ」のchobiit-copy-contents-clear-caches-containerを開くと「ログドライバー: awslogs CloudWatch のログを表示」とあるのでここからcloudwatchで確認が可能です。

